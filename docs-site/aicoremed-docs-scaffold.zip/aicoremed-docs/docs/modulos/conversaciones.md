# Conversaciones (WhatsApp/Email)

> **Estado de esta pagina:** plantilla inicial. Completar con el detalle real del modulo
> antes de considerarla lista.

## Que hace este modulo

<!-- Descripcion funcional en 2-3 parrafos -->

## Rutas y componentes principales

| Ruta / Componente | Descripcion |
|---|---|
| `app/dashboard/...` | |
| `lib/services/...` | |
| `app/api/...` | |

## Modelo de datos relacionado

<!-- Tablas de Drizzle involucradas -- enlazar a docs/existente/base-de-datos.md -->

## Reglas de negocio importantes

## Integraciones externas

## Decisiones de arquitectura relevantes

<!-- Enlazar ADRs de docs/decisiones/ -->
